$("#skill1").on("mouseenter", function() {
    $("#skill1").animate({ opacity: 2 }).text("90%")
})
$("#skill1").on("mouseleave", function() {
    $("#skill1").animate({ opacity: 2 }).text("HTML")
})

$("#skill2").on("mouseenter", function() {
    $("#skill2").animate({ opacity: 2 }).text("70%")
})
$("#skill2").on("mouseleave", function() {
    $("#skill2").animate({ opacity: 2 }).text("CSS")
})

$("#skill3").on("mouseenter", function() {
    $("#skill3").animate({ opacity: 2 }).text("70%")
})
$("#skill3").on("mouseleave", function() {
    $("#skill3").animate({ opacity: 2 }).text("JavaScript")
})

$("#skill4").on("mouseenter", function() {
    $("#skill4").animate({ opacity: 2 }).text("80%")
})
$("#skill4").on("mouseleave", function() {
    $("#skill4").animate({ opacity: 2 }).text("Django")
})


$("#skill5").on("mouseenter", function() {
    $("#skill5").animate({ opacity: 2 }).text("80%")
})
$("#skill5").on("mouseleave", function() {
    $("#skill5").animate({ opacity: 2 }).text("JQuery")
})